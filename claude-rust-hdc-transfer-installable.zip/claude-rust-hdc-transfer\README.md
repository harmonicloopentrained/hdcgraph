# Claude Rust HDC Transfer Pack

This package turns the working Codex Rust/WGSL HDC graph workflow into a Claude-native plugin and project install bundle.

It keeps one shared graph pack in the repo at `.codex/rust-hdc-graph/`, then lets Claude use that same pack through a repo-local plugin at `.claude/skills/rust-hdc-graph/`.

## Global Install (Desktop App, every chat, no reload)

This pack ships a marketplace manifest at `.claude-plugin/marketplace.json`, so you can
install the plugin once for your user and have it load in every Claude Code session
(desktop app included) without a per-chat `/reload-plugins`:

```powershell
claude plugin marketplace add "<path-to>\claude-rust-hdc-transfer" --scope user
claude plugin install rust-hdc-graph@rust-hdc-graph-pack --scope user
```

The marketplace `source` references this folder in place, so keep it on disk (or move it
and re-run `marketplace add` from the new path). Restart the desktop app once after
installing so the new session picks up the plugin and its hooks.

## What You Get

- A Claude plugin at `claude-plugin/rust-hdc-graph/`
- A repo installer at `scripts/install-into-project.ps1`
- Shared graph-pack assets vendored into the plugin under `assets/project-template/`
- Soft always-on Claude reminders via plugin hooks
- Optional strict guardrails that block broad search until Claude runs graph `context` or `query`
- Handoff docs for asking another Claude session to install or extend the setup

## Quick Install

From this transfer-pack folder, install into a target repo:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\scripts\install-into-project.ps1 -ProjectRoot C:\path\to\repo
```

To also enable strict graph-first enforcement:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\scripts\install-into-project.ps1 -ProjectRoot C:\path\to\repo -StrictGuardrails
```

The installer will:

1. Copy the shared graph pack into `<repo>\.codex\rust-hdc-graph\`
2. Copy the Claude plugin into `<repo>\.claude\skills\rust-hdc-graph\`
3. Install the graph-first block into `AGENTS.md`
4. Install a Claude bridge block into `CLAUDE.md`
5. Optionally merge a strict `PreToolUse` hook into `.claude/settings.json`

If the repo-local plugin was copied while Claude Code was already open in that repo, run `/reload-plugins` or restart Claude Code.

## How Claude Uses It

The repo-local Claude plugin exposes these skills:

- `/rust-hdc-graph:bootstrap`
- `/rust-hdc-graph:context`
- `/rust-hdc-graph:query`
- `/rust-hdc-graph:refresh`

It also ships one model-invoked background skill:

- `graph-first`

That skill tells Claude to use the shared graph pack before broad codebase search for Rust and WGSL architecture work, symbol tracing, shader wiring, and task context gathering.

## Shared Layout

Authoritative shared graph state:

```text
<repo>/.codex/rust-hdc-graph/
```

Claude repo-local plugin:

```text
<repo>/.claude/skills/rust-hdc-graph/
```

This split is what makes the workflow transferable:

- Codex and Claude both point at the same graph data and extractor source
- Claude gets its own native skills and hooks without forking the graph artifacts
- Future agents can work from repo-local files instead of machine-global setup

## Package Map

- `claude-plugin/rust-hdc-graph/`
  - Claude plugin to install globally or copy into a repo
- `scripts/install-into-project.ps1`
  - one-shot installer for a target repo
- `docs/claude-handoff.md`
  - exact prompt and checklist for another Claude session
- `docs/codex-to-claude-map.md`
  - concept mapping from the Codex build to the Claude build

## Notes

- This pack targets the current Windows and PowerShell workflow used for Chrysalis.
- The Claude plugin uses official Claude Code skills, plugins, hooks, `CLAUDE.md`, and skills-directory plugin behavior.
- Soft plugin hooks are always on when the plugin is enabled. Strict blocking is optional because it is more opinionated.
